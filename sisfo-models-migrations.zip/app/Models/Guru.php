<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Guru extends Model
{
    protected $table = 'guru';

    protected $fillable = ['nip', 'nama', 'jenis_kelamin', 'no_hp', 'alamat'];

    public function mapel()
    {
        return $this->hasMany(Mapel::class);
    }
}
